--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.2
-- Dumped by pg_dump version 12.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "ShadowHunterDatabase";
--
-- Name: ShadowHunterDatabase; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "ShadowHunterDatabase" WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'French_France.1252' LC_CTYPE = 'French_France.1252';


ALTER DATABASE "ShadowHunterDatabase" OWNER TO postgres;

\connect "ShadowHunterDatabase"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: CartesLumiere; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CartesLumiere" (
    id integer NOT NULL,
    nom text NOT NULL,
    image bytea
);


ALTER TABLE public."CartesLumiere" OWNER TO postgres;

--
-- Name: CartesPersonnage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CartesPersonnage" (
    id integer NOT NULL,
    nom text NOT NULL,
    image bytea
);


ALTER TABLE public."CartesPersonnage" OWNER TO postgres;

--
-- Name: CartesTenebre; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CartesTenebre" (
    id integer NOT NULL,
    nom text NOT NULL,
    image bytea
);


ALTER TABLE public."CartesTenebre" OWNER TO postgres;

--
-- Name: CartesVision; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CartesVision" (
    id integer NOT NULL,
    nom text NOT NULL,
    image bytea
);


ALTER TABLE public."CartesVision" OWNER TO postgres;

--
-- Name: CartesAll; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public."CartesAll" AS
 SELECT "CartesLumiere".id,
    "CartesLumiere".nom,
    "CartesLumiere".image
   FROM public."CartesLumiere"
UNION
 SELECT "CartesTenebre".id,
    "CartesTenebre".nom,
    "CartesTenebre".image
   FROM public."CartesTenebre"
UNION
 SELECT "CartesVision".id,
    "CartesVision".nom,
    "CartesVision".image
   FROM public."CartesVision"
UNION
 SELECT "CartesPersonnage".id,
    "CartesPersonnage".nom,
    "CartesPersonnage".image
   FROM public."CartesPersonnage"
  ORDER BY 1;


ALTER TABLE public."CartesAll" OWNER TO postgres;

--
-- Data for Name: CartesLumiere; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CartesLumiere" (id, nom, image) FROM stdin;
\.
COPY public."CartesLumiere" (id, nom, image) FROM '$$PATH$$/2840.dat';

--
-- Data for Name: CartesPersonnage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CartesPersonnage" (id, nom, image) FROM stdin;
\.
COPY public."CartesPersonnage" (id, nom, image) FROM '$$PATH$$/2843.dat';

--
-- Data for Name: CartesTenebre; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CartesTenebre" (id, nom, image) FROM stdin;
\.
COPY public."CartesTenebre" (id, nom, image) FROM '$$PATH$$/2841.dat';

--
-- Data for Name: CartesVision; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CartesVision" (id, nom, image) FROM stdin;
\.
COPY public."CartesVision" (id, nom, image) FROM '$$PATH$$/2842.dat';

--
-- Name: CartesLumiere CartesLumiere_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CartesLumiere"
    ADD CONSTRAINT "CartesLumiere_pkey" PRIMARY KEY (id);


--
-- Name: CartesPersonnage CartesPersonnage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CartesPersonnage"
    ADD CONSTRAINT "CartesPersonnage_pkey" PRIMARY KEY (id);


--
-- Name: CartesTenebre CartesTenebre_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CartesTenebre"
    ADD CONSTRAINT "CartesTenebre_pkey" PRIMARY KEY (id);


--
-- Name: CartesVision CartesVision_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CartesVision"
    ADD CONSTRAINT "CartesVision_pkey" PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

